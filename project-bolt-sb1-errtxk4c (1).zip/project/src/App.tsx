import React, { useState, useEffect } from 'react';
import { Vote, BarChart, User2, Plus, Minus, Trophy, Clock, Download, Trash2 } from 'lucide-react';

interface Candidate {
  name: string;
  votes: number;
}

function App() {
  const [candidates, setCandidates] = useState<Candidate[]>([
    { name: "Sławomir Mentzen", votes: 5 },
    { name: "Szymon Hołownia", votes: 0 },
    { name: "Rafał Trzaskowski", votes: 9 },
    { name: "Karol Nawrocki", votes: 0 },
    { name: "Marek Jakubiak", votes: 1 },
    { name: "Grzegorz Braun", votes: 0 },
    { name: "Magdalena Biejat", votes: 2 },
    { name: "Krzysztof Stanowski", votes: 0 },
    { name: "Adrian Zandberg", votes: 0 },
    { name: "Piotr Szumlewicz", votes: 0 },
    { name: "Paweł Tanajno", votes: 0 },
    { name: "Niezdecydowany/a", votes: 2 }
  ]);

  const [lastUpdate, setLastUpdate] = useState<string>('');

  const totalVotes = candidates.reduce((sum, candidate) => sum + candidate.votes, 0);
  const maxVotes = Math.max(...candidates.map(c => c.votes));
  const leadingCandidate = candidates.find(c => c.votes === maxVotes);
  const sortedCandidates = [...candidates].sort((a, b) => b.votes - a.votes);

  const handleVoteChange = (name: string, increment: boolean) => {
    setCandidates(prev => prev.map(candidate => 
      candidate.name === name
        ? { ...candidate, votes: Math.max(0, candidate.votes + (increment ? 1 : -1)) }
        : candidate
    ));
    setLastUpdate(new Date().toLocaleString('pl-PL'));
  };

  const handleReset = () => {
    if (window.confirm('Czy na pewno chcesz zresetować wszystkie głosy?')) {
      setCandidates(prev => prev.map(candidate => ({ ...candidate, votes: 0 })));
      setLastUpdate(new Date().toLocaleString('pl-PL'));
    }
  };

  const handleExport = () => {
    const data = {
      candidates,
      totalVotes,
      lastUpdate,
      exportDate: new Date().toLocaleString('pl-PL')
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sonda-wyborcza-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  useEffect(() => {
    localStorage.setItem('pollData', JSON.stringify(candidates));
    localStorage.setItem('lastUpdate', lastUpdate);
  }, [candidates, lastUpdate]);

  useEffect(() => {
    const savedData = localStorage.getItem('pollData');
    const savedUpdate = localStorage.getItem('lastUpdate');
    if (savedData) {
      setCandidates(JSON.parse(savedData));
    }
    if (savedUpdate) {
      setLastUpdate(savedUpdate);
    } else {
      setLastUpdate(new Date().toLocaleString('pl-PL'));
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Vote className="w-8 h-8 text-blue-600" />
              <h1 className="text-2xl md:text-3xl font-bold text-gray-800">
                Sonda Wyborcza 2024
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={handleExport}
                className="flex items-center gap-2 px-4 py-2 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span className="hidden sm:inline">Eksportuj dane</span>
              </button>
              <button
                onClick={handleReset}
                className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span className="hidden sm:inline">Resetuj</span>
              </button>
              <div className="flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-lg">
                <User2 className="w-5 h-5 text-blue-600" />
                <span className="text-blue-700 font-medium">
                  {totalVotes}
                </span>
              </div>
            </div>
          </div>

          {leadingCandidate && leadingCandidate.votes > 0 && (
            <div className="mb-8 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl p-4 border border-yellow-200">
              <div className="flex items-center gap-3">
                <Trophy className="w-6 h-6 text-yellow-600" />
                <span className="text-lg font-semibold text-gray-800">
                  Prowadzi: {leadingCandidate.name} ({leadingCandidate.votes} głosów)
                </span>
              </div>
            </div>
          )}

          <div className="space-y-6">
            {candidates.map((candidate) => {
              const percentage = totalVotes > 0 
                ? ((candidate.votes / totalVotes) * 100).toFixed(1) 
                : "0";

              return (
                <div key={candidate.name} 
                  className="bg-gray-50 rounded-lg p-4 transition-all duration-200 hover:shadow-md">
                  <div className="flex items-center gap-4 mb-3">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-800">{candidate.name}</h3>
                      <div className="text-sm text-gray-500">
                        {candidate.votes} {candidate.votes === 1 ? 'głos' : 'głosów'} ({percentage}%)
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleVoteChange(candidate.name, false)}
                        className="p-2 rounded-lg hover:bg-red-100 text-red-600 transition-colors"
                        disabled={candidate.votes === 0}
                      >
                        <Minus className="w-5 h-5" />
                      </button>
                      <span className="w-12 text-center font-medium">
                        {candidate.votes}
                      </span>
                      <button
                        onClick={() => handleVoteChange(candidate.name, true)}
                        className="p-2 rounded-lg hover:bg-green-100 text-green-600 transition-colors"
                      >
                        <Plus className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-blue-600 transition-all duration-500 ease-out"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-8 space-y-6">
            <div className="bg-gray-50 p-6 rounded-xl">
              <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <BarChart className="w-5 h-5 text-blue-600" />
                Wykres poparcia
              </h2>
              <div className="space-y-3">
                {sortedCandidates.map((candidate) => {
                  const percentage = totalVotes > 0 
                    ? ((candidate.votes / totalVotes) * 100).toFixed(1) 
                    : "0";
                  
                  return candidate.votes > 0 ? (
                    <div key={`chart-${candidate.name}`} className="flex items-center gap-4">
                      <div className="w-32 text-sm text-gray-600 truncate">
                        {candidate.name}
                      </div>
                      <div className="flex-1 h-6 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-blue-600 flex items-center px-2 text-white text-sm transition-all duration-500"
                          style={{ width: `${percentage}%` }}
                        >
                          {percentage}%
                        </div>
                      </div>
                      <div className="w-16 text-right text-sm font-medium text-gray-700">
                        {candidate.votes}
                      </div>
                    </div>
                  ) : null;
                })}
              </div>
            </div>

            <div className="bg-blue-50 rounded-lg p-4">
              <div className="flex items-center gap-2 text-blue-700 mb-2">
                <Clock className="w-5 h-5" />
                <span className="font-medium">Informacje</span>
              </div>
              <div className="text-sm text-gray-600 space-y-1">
                <div>• Ostatnia aktualizacja: {lastUpdate}</div>
                <div>• Zapisywanie automatyczne w pamięci przeglądarki</div>
                <div>• Możliwość eksportu danych do pliku</div>
                <div>• Wizualizacja wyników na wykresie</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;